function setup() {
 createCanvas(800, 300);
 background(220,220,220);
  rectMode(CENTER);
}
function draw() {
  background(220);
 rect(400, 150, 100, 100);
  fill(136,86,167);
  ellipse(350,120,100,100);
  fill(158,188,218);
  line(1,1,1000,300);
}